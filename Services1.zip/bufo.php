<?php
if ($_REQUEST['name']) {
	 $c = "./bufoServer ". $_REQUEST['name'];
	 system($c); 
}
else {
	echo "argc and argv disabled\n";
}
?>